package com.memory.opengl

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val surface: MyGLSurfaceView = findViewById(R.id.my_gl_surface_view)
        findViewById<Button>(R.id.btn).setOnClickListener {

        }
    }
}