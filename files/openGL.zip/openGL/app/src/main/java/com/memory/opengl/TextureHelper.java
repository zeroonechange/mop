package com.memory.opengl;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.util.Log;

public class TextureHelper {

    //返回纹理id
    public static int loadTexture(Context context, int resouurceId) {
        int[] textureId = new int[1];
        //获取纹理id
        GLES20.glGenTextures(1, textureId, 0);
        if (textureId[0] == 0) {
            Log.d("mmm", "没有成功创建一个新的Texture");
            return 0;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inScaled = false;

        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), resouurceId, options);

        if (bitmap == null) {
            Log.d("mmm", "创建bitmap失败");
            GLES20.glDeleteTextures(1, textureId, 0);
            return 0;
        }

        /**
         * 第一个参数：告诉opengl作为一个二维纹理对待
         * 第二个参数：告诉opengl，要绑定那个纹理id
         */
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId[0]);

        //设置过滤器
        /**
         * GL_TEXTURE_MIN_FILTER:在缩小的情况下用  GL_LINEAR_MIPMAP_LINEAR：三线性过滤
         * GL_TEXTURE_MAG_FILTER：在放大的情况下用  GL_TEXTURE_MAG_FILTER：双线性过滤
         */
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

        //把图片加载到opengl里面
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
        //释放bitmap
        bitmap.recycle();
        //生成mip贴图
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);

        //解除纹理绑定  第二个参数传0 就是解除绑定
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);

        return textureId[0];

    }
}
