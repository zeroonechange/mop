package com.memory.opengl

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLSurfaceView
import android.util.AttributeSet

class MyGLSurfaceView(context: Context?, attrs: AttributeSet?) : GLSurfaceView(context, attrs) {


 /*      val renderer: MyGLRenderer

       init {
           // 创建一个OpenGL ES 2.0上下文
           setEGLContextClientVersion(2)
           renderer = MyGLRenderer()
           // GLSurfaceView关联Render
           setRenderer(renderer)
           renderMode = RENDERMODE_WHEN_DIRTY
       }*/

    /****************************************************/

/*    val renderer: MyGLBitmapRenderer

    init {
        // 创建一个OpenGL ES 2.0上下文
        setEGLContextClientVersion(2)
        renderer = MyGLBitmapRenderer()
        // GLSurfaceView关联Render
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        val bitmap1 = BitmapFactory.decodeResource(context?.resources, R.drawable.hair_01)
        val bitmap2 = BitmapFactory.decodeResource(context?.resources, R.drawable.top_03)
//        val bitmap = BitmapFactory.decodeResource(context?.resources, R.drawable.hair_02)

        renderer.setImageBitmap(arrayListOf(bitmap1, bitmap2))
    }

    fun add(){
        val bitmap = BitmapFactory.decodeResource(context?.resources, R.drawable.top_03)
//        renderer.addBitmap(bitmap)
    }*/



    val renderer: MultiTextureRenderer

    init {
        // 创建一个OpenGL ES 2.0上下文
        setEGLContextClientVersion(2)
        renderer = MultiTextureRenderer(context)
        // GLSurfaceView关联Render
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

}
